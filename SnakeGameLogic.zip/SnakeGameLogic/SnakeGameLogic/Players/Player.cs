﻿using SnakeGameLogic.Powerups;
using System.Numerics;

namespace SnakeGameLogic.Players
{
    public class Player
    {
        public string Name { get; set; }
        public int Position { get; set; }
        public bool ExtraRoll { get; internal set; }
        public bool SkipSnake { get; internal set; }
        public bool MustRollEven { get; internal set; }

        public Player(string name) 
        {  
            Name = name;
        }

        public void ApplyPowerUp(IPowerup powerup)
        {
            powerup.Apply(this);
        }

        public void MoveForward(int steps) 
        {
            Console.WriteLine($"o {Name} vrike ena powerUp FastForward kai proxoraei {steps} vimata");
                Position += steps;                         
        }

        public void MoveBack(int steps)
        {
            Console.WriteLine($"o {Name} vrike enan Exthro pou ton anagkazi na paei pisw {steps} vimata");
            Position -= steps;
        }
    }
}
