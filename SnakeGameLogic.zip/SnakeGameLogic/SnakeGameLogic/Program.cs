﻿using SnakeGameLogic.Board;
using SnakeGameLogic.Game;
using SnakeGameLogic.Players;
using System.Numerics;

namespace SnakeGameLogic
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kalosirthate sto Ananewmeno Fidaki!");

            GameBoard board = new GameBoard();
            board.SetupGameBoard();

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Dwste onomata stous paixtes!");

            Console.Write("Player 1: ");
            string name1 = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name1)) name1 = "P1";

            Console.Write("Player 2: ");
            string name2 = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name2)) name2 = "P2";


            Player player1 = new Player(name1);
            Player player2 = new Player(name2);

            GameLogic game = new GameLogic(board, new List<Player> { player1, player2 });

            // 4. Εκκίνηση παιχνιδιού
            while (!game.isGameOver)
            {
                Player currentPlayer = game.GetCurrentPlayer();

                Console.WriteLine($"\n{currentPlayer.Name} einai i seira sou (thesi {currentPlayer.Position}). pata ena opiodipote koumpi gia na rikseis to zari...");
                Console.ReadKey();

                game.PlayTurn(currentPlayer);

                if (!game.isGameOver)
                {
                    if (currentPlayer.ExtraRoll)
                    {
                        currentPlayer.ExtraRoll = false;

                    }
                    else
                    {
                        game.NextTurn();
                    }
                        
                }
            }

            Console.WriteLine("Game Over!");

        }
    }
}
