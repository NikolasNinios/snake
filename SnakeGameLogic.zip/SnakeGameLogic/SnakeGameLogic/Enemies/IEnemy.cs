﻿using SnakeGameLogic.Players;

public interface IEnemy
{
    void ApplyPenalty(Player player);
}

