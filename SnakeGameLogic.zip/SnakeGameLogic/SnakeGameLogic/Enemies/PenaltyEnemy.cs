﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Enemies
{
    public class PenaltyEnemy : IEnemy
    {
        public void ApplyPenalty (Player player)
        {
            Random rnd = new Random();
            int steps = rnd.Next(1, 4);
            player.MoveBack(steps);
        }
    }
}
