﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Enemies
{
    public class StaticEnemy : IEnemy
    {

        public void ApplyPenalty(Player player)
        {
            Console.WriteLine($"o {player.Name} vrike enan exthro pou gia na ton afhsei na proxorisei prepei na ferei zigo arithmo sto zari");
            player.MustRollEven = true;
        }
    }
}
