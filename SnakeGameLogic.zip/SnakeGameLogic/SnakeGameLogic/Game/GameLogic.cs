﻿using SnakeGameLogic.Board;
using SnakeGameLogic.Players;

namespace SnakeGameLogic.Game
{
    public class GameLogic
    {

        public List<Player> players = new List<Player>();
        int currentPlayerIndex;
        GameBoard board;
        public bool isGameOver = false;
        Random rng = new Random();


        public GameLogic(GameBoard board, List<Player> players)
        {
            this.board = board;
            this.players = players;
            this.currentPlayerIndex = 0;
        }


        int RollDice()
        {
            return rng.Next(1, 7);
        }

        public void PlayTurn(Player player)
        {

            var dice = RollDice();
            Console.WriteLine($"O {player.Name} erikse to zari kai efere {dice}");
            

            if (player.MustRollEven)
            {

                if (dice % 2 == 0)
                {
                    Console.WriteLine("Efere zigo epitelous!");
                    player.MustRollEven = false;
                }
                else
                {
                    Console.WriteLine("Efere mono xanei tin seira tou.");
                    return;
                }


            }

            player.Position += dice;

            if (player.Position >= 100)
            {
                player.Position = 100;
                isGameOver = true;
                Console.WriteLine($"Player {player.Name} Won the Game!!");
                return;
            }


            var tile = board.GetTileAt(player.Position);

            tile.OnLand(player);

            Console.WriteLine($"h kainourgia thesi tou {player.Name} einai {player.Position}");
     

        }


        public void NextTurn()
        {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.Count;
        }


        public Player GetCurrentPlayer()
        {
            return players[currentPlayerIndex];
        }


    }
}
