﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Board
{
    public class LadderTile :Tile
    {
        private int Destination {  get; set; }

        public LadderTile(int destination,int position):base(position)
        {
            Destination = destination;
       
        }

        public override void OnLand(Player player)
        {
            Console.WriteLine($"O {player.Name} vrike skala stin thesi {player.Position}!!");
            player.Position = Destination;


        }


    }
}
