﻿using SnakeGameLogic.Board;
using SnakeGameLogic.Players;

public class EnemyTile : Tile
{
    private IEnemy Enemy;

    public EnemyTile(int position, IEnemy enemy) : base(position)
    {
        Enemy = enemy;
    }

    public override void OnLand(Player player)
    {
        Enemy.ApplyPenalty(player);
    }
}

