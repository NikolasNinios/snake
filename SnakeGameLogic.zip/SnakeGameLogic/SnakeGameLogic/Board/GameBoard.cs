﻿

using SnakeGameLogic.Enemies;
using SnakeGameLogic.Powerups;

namespace SnakeGameLogic.Board
{
    public class GameBoard
    {
        public int FinalTileIndex;
        public int size;
        public Dictionary<int, Tile> tiles;

        public void SetupGameBoard()
        {
            size = 100;
            FinalTileIndex = 100;
            tiles = new Dictionary<int, Tile>();

            //ladder tiles
            tiles[4] = new LadderTile(26, 4);
            tiles[9] = new LadderTile(30, 9);
            tiles[13] = new LadderTile(56, 13);
            tiles[19] = new LadderTile(38, 19);
            tiles[37] = new LadderTile(59, 37);
            tiles[48] = new LadderTile(69, 48);
            tiles[60] = new LadderTile(83, 60);
            tiles[73] = new LadderTile(89, 73);
            tiles[77] = new LadderTile(96, 77);

            //snake tiles
            tiles[23] = new SnakeTile(6, 23);
            tiles[50] = new SnakeTile(27, 50);
            tiles[54] = new SnakeTile(24, 54);
            tiles[65] = new SnakeTile(40, 65);
            tiles[81] = new SnakeTile(58, 81);
            tiles[94] = new SnakeTile(70, 94);
            tiles[98] = new SnakeTile(67, 98);



            //powerups tiles
            tiles[1] = new PowerupTile(1, new FastForward());
            tiles[97] = new PowerupTile(97, new SkipSnake());
            tiles[35] = new PowerupTile(35, new SkipSnake());
            tiles[91] = new PowerupTile(91, new FastForward());
            tiles[10] = new PowerupTile(10, new ExtraRoll());
            tiles[56] = new PowerupTile(56, new ExtraRoll());

            //enemies tiles
            tiles[99] = new EnemyTile(99, new PenaltyEnemy());
            tiles[68] = new EnemyTile(68, new PenaltyEnemy());
            tiles[39] = new EnemyTile(39, new PenaltyEnemy());
            tiles[96] = new EnemyTile(96, new StaticEnemy());
            tiles[14] = new EnemyTile(14, new StaticEnemy());
            tiles[47] = new EnemyTile(47, new StaticEnemy());


            for (int i = 1; i <= 100; i++)
            {
                if (!tiles.ContainsKey(i))
                {
                    tiles[i] = new NormalTile(i);
                }
            }


        }

        public Tile GetTileAt(int position)
        {
            var tile = tiles[position];
            return tile;
        }

    }
}
