﻿using SnakeGameLogic.Players;
using SnakeGameLogic.Powerups;

namespace SnakeGameLogic.Board
{
    public class PowerupTile : Tile
    {
        public IPowerup Powerup { get; set; }

        public PowerupTile(int position, IPowerup powerup) : base(position)
        {

            Powerup = powerup;

        }

        public override void OnLand(Player player)
        {
            player.ApplyPowerUp(Powerup);

        }

    }
}
