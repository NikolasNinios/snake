﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Board
{
    public abstract class Tile
    {
        public int Position {  get; set; }

        public Tile (int position)
        {
            Position = position;
        }

        public abstract void OnLand(Player player);
    }
}
