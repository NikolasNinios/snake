﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Board
{
    public class NormalTile:Tile
    {
        public NormalTile(int position):base(position) { }

        public override void OnLand(Player player)
        {
            //Console.WriteLine($"O {player.Name} vriskete stin thesi {Position}");
        }
    }
}
