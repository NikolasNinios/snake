﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Board
{
    public class SnakeTile :Tile
    {
        private int Destination {  get; set; }

        public SnakeTile(int destination,int position):base(position)
        {
            Destination = destination;
       
        }

        public override void OnLand(Player player)
        {
            if (player.SkipSnake == false)
            {
                Console.WriteLine($"i thesi {player.Position} exei ena kako fidi");
                player.Position = Destination;
            }
            else
            {
                Console.WriteLine("o paixtis exei anosia sta fidia!! :D");
                player.SkipSnake = false;
            }
            
        }

    }
}
