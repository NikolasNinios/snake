﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Powerups
{
    public class ExtraRoll : IPowerup
    {
        public void Apply(Player player)
        {
            Console.WriteLine($"o {player.Name} tha ksanapaiksei epeidh vrike plakidio me powerup(extraRoll)");
            player.ExtraRoll = true;
        }

    }
}
