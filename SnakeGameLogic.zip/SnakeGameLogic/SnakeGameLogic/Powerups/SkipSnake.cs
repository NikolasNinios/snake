﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Powerups
{
    public class SkipSnake : IPowerup
    {
        public void Apply(Player player)
        {
            Console.WriteLine($"o {player.Name} exei anosia sta fidia epeidh vrike plakidio me powerup(SkipSnake)");
            player.SkipSnake = true;

        }
    }
}
