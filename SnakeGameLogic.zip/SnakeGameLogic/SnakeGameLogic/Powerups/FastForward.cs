﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Powerups
{
    public class FastForward : IPowerup
    {
        public void Apply(Player player)
        {
            Random rnd = new Random();
            int steps = rnd.Next(1, 4);
            player.MoveForward(steps);
        }
    }
}
