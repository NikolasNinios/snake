﻿using SnakeGameLogic.Players;

namespace SnakeGameLogic.Powerups
{
    public interface IPowerup
    {
        public void Apply(Player player);
    }
}
